#include "../dict.h"

struct dict
{
	bool *arr;
	int max_size;
};
//void mysprinter(dict *x);

